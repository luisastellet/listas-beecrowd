#EXERCÍCIO 1
X, Y = input().split()
Xint = int(X)
Yint = int(Y)
maior = X
if Yint > Xint:
    maior = Yint
print(maior)