#EXERCÍCIO 2
N = int(input())
M = int(input())
print(N-M)