#EXERCÍCIO 3
Xm, Ym, Xr, Yr = map(int,input().split())
dist = abs(Xr - Xm) + abs(Yr - Ym)
print(dist)